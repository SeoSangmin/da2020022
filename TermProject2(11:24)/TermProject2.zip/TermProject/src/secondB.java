import java.util.*;
public class secondB {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Random rd = new Random();
		termproject pr = new termproject();
		
		System.out.println("N(데이터 갯수)와 K(구간의 갯수)를 차례대로 입력하세요.");
		int N = sc.nextInt();
		int K = sc.nextInt();
		
		pr.array = new int[N];
		for (int i = 0; i < N; i++) {
	        pr.array[i] = rd.nextInt();
	    }
		
		for(int i=0; i<K; i++) {
			int a1 = (rd.nextInt(N-1)+1);
			int plus = rd.nextInt(N-a1);
			int a2 = a1+plus;
			
			int minimum = pr.mini(a1, a2);
			int maximum = pr.maxi(a1, a2);
			int sum = pr.sum(a1, a2);
			System.out.println("구간 : "+a1+"-"+a2);
			System.out.println(minimum+" "+maximum+" "+sum+"\n");
		}
		sc.close();
	}
}


