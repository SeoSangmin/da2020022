import java.util.*;
class project {
	Scanner sc = new Scanner(System.in);
	Random rd = new Random();
	int min;
	int max;
	int sum;
	int size;
	int a1;
	int a2;
	int[] array;
	project() {}
	public int mini(int a1, int a2) {
		min = array[a1];
	    for(int i=a1-1;i<a2;i++) {
	    	if(array[i]<min) {
	    		min = array[i];
	    	}
	    }
		return min;
	}
	public int maxi(int a1, int a2) {
		max = array[a1];
		for(int i=a1-1;i<a2;i++) {
			if(array[i]>max) {
	    		max = array[i];
	    	}
		}
		return max;
	}
	public int sum(int a1, int a2) {
		sum = 0;
		for(int i=a1-1;i<a2;i++) {
			sum += array[i];
		}
		return sum;
	}
}
public class firstA {
	
	public static void main(String[] args) {
		System.out.println("N(데이터 갯수)와 구간 a, b를 차례대로 입력하세요.");
		Scanner sc = new Scanner(System.in);
		Random rd = new Random();
		project pr1 = new project();
		
		pr1.size = sc.nextInt();
		pr1.a1 = sc.nextInt();
		pr1.a2 = sc.nextInt();
		int b1 = sc.nextInt();
		int b2 = sc.nextInt();
		pr1.array = new int[pr1.size];
		for (int i = 0; i < pr1.array.length; i++) {
	        pr1.array[i] = rd.nextInt(100);
	    }
		sc.close();

		int minimum = pr1.mini(pr1.a1, pr1.a2);
		int maximum = pr1.maxi(pr1.a1, pr1.a2);
		int sum = pr1.sum(pr1.a1, pr1.a2);
		
		int minimum2 = pr1.mini(b1, b2);
		int maximum2 = pr1.maxi(b1, b2);
		int sum2 = pr1.sum(b1, b2);
		
		System.out.println(minimum+" "+maximum+" "+sum);
		System.out.println(minimum2+" "+maximum2+" "+sum2);
   
		for(int i=0;i<pr1.array.length;i++)
			System.out.println(pr1.array[i]);
	}
}
	
