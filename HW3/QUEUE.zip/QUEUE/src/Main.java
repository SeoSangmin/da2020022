import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

class Queue{
	public int[] que = new int[1000];
	public int front;
	public int back;
	
	public int size() {
		int size = back - front + 1;
		return size;
	}
	public boolean empty() {
		if(size()>=0) {return true;}
		else {return false;}
	}
	
	public void push(int v) {
		que[++back] = v;
	}
	
	public int pop() {
		if(empty()) {return -1;}
		else {int f = que[front--];return f;}
	}
	
	public int front() {
		if(empty()) {return -1;}
		else {return que[front];}
	}
	
	public int back() {
		if(empty()) {return -1;}
		else {return que[back];}
	}
	
	
}

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int n = Integer.parseInt(br.readLine());
        Queue que = new Queue();

        for(int i=0; i<n; i++){
            StringTokenizer st = new StringTokenizer(br.readLine());
            String str = st.nextToken();
            if(str.equals("push")) {que.push(Integer.parseInt(st.nextToken()));}
            
            else if(str.equals("pop")) 
            {if(!que.empty()) {System.out.println(que.pop());;}else{System.out.println("-1");}}
            
            else if(str.equals("size")) 
            {System.out.println(que.size());}
            
            else if(str.equals("empty")) 
            {if(que.empty()) {System.out.println("1");}else{System.out.println("0");}}
            
            else if(str.equals("front")) 
            {if(!que.empty()) {System.out.println(que.front);}else{System.out.println("-1");}}
            
            else 
            {if(!que.empty()) {System.out.println(que.back);}else{System.out.println("-1");}}
            
        }
    }
}

