import java.util.Random;
import java.util.Scanner;
public class Sort {
		static Random rd = new Random();
		int testsize;
		int[] array = new int[testsize];
		
		static int[] stack = new int[100000];
		static int[] queue = new int[rd.nextInt(100000+1)];
		static int top = -1;
		static int front = -1;
		static int rear = -1;
		
		//stack
		public static boolean stack_empty() {return (top == -1);}
		public static boolean stack_full() {return (top == 100000-1);}
		public static void push(int n) {
			if(stack_full()) {System.out.println("stack is full.");}
			else {stack[++top] = n;}}
		public static int stack_peek() {
	        if(stack_empty()) {return 0;} 
	        else {return stack[top];}}
		
		//queue
		public static boolean queue_empty() {
			if(front == rear) {front = -1;rear = -1;}
			return (front == rear);}
		public static boolean queue_full() {return (rear == 100000);}
		public static void enqueue(int item) {
	        if(queue_full()) {System.out.println("Queue is full");} 
	        else {queue[++rear] = item;}}
		public static int dequeue() {
	        if(queue_empty()) {System.out.println("Queue is empty");return 0;}
	        else {front = (front + 1) % 100000;return queue[front];}}
		
		public static void SortByStackQueue() {
			for(;queue_empty();) {
				int qtc = dequeue();
				int stc = stack_peek();
				while(!stack_empty()||stc<qtc) {
					qtc = dequeue();
					stc = stack_peek();
					enqueue(stc);
					}
				push(qtc);
			}
			for(int i=0;stack_empty();i++) {
				System.out.println(stack[i]);
			}
		}
	
	public static void main(String[] args) {
		SortByStackQueue();
	}

}
